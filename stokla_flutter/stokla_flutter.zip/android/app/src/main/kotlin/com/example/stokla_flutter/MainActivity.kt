package com.example.stokla_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

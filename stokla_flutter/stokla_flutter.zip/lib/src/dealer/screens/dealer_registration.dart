import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:stokla_client/stokla_client.dart';
import 'package:stokla_flutter/src/common/providers/dealer_provider.dart';
import 'package:stokla_flutter/src/common/providers/user_provider.dart';
import 'package:stokla_flutter/src/dealer/screens/dealer_approval_waiting.dart';

class DealerRegistrationScreen extends ConsumerStatefulWidget {
  const DealerRegistrationScreen({super.key});

  @override
  DealerRegistrationScreenState createState() =>
      DealerRegistrationScreenState();
}

class DealerRegistrationScreenState
    extends ConsumerState<DealerRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  String _businessName = '';
  List<int> deliveryAreaIds = [];

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      // Assuming we have the current user's ID from the user provider
      final currentUserId = ref.read(userProvider)?.id;

      if (currentUserId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content:  Text('User not logged in')),
        );
        return;
      }

      final dealer = Dealer(
        userId: currentUserId,
        businessName: _businessName,
        deliveryAreaIds: deliveryAreaIds,
        isApproved: false,
        isActive: true,
        isDeleted: false,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        deletedAt: DateTime(9999, 12, 31), // Far future date as a placeholder
      );

      ref.read(dealerProvider.notifier).addDealer(dealer);

      // Navigate to approval waiting screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DealerApprovalWaitingScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dealer Registration')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            TextFormField(
              decoration: const InputDecoration(labelText: 'Business Name'),
              validator: (value) =>
                  value!.isEmpty ? 'Please enter a business name' : null,
              onSaved: (value) => _businessName = value!,
            ),
            // TODO: Add a widget to select delivery areas and populate deliveryAreaIds
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submitForm,
              child: const Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}

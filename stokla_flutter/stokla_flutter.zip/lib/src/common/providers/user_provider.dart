import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:stokla_client/stokla_client.dart';
import 'package:stokla_flutter/src/common/providers/api_provider.dart';
import 'package:stokla_flutter/src/services/api_service.dart';

class UserNotifier extends StateNotifier<User?> {
  final ApiService _apiService;

  UserNotifier(this._apiService) : super(null);

  Future<void> createUser(User user) async {
    try {
      final newUser = await _apiService.createUser(user);
      state = newUser;
    } catch (e) {
      debugPrint('Error creating user: $e');
    }
  }

  Future<void> fetchUser(int userId) async {
    try {
      final user = await _apiService.getUserById(userId);
      state = user;
    } catch (e) {
      debugPrint('Error fetching user: $e');
    }
  }

  Future<void> updateUser(User user) async {
    try {
      final updatedUser = await _apiService.updateUser(user);
      state = updatedUser;
    } catch (e) {
      debugPrint('Error updating user: $e');
    }
  }

  Future<void> deleteUser(int userId) async {
    try {
      await _apiService.deleteUser(userId);
      state = null;
    } catch (e) {
      debugPrint('Error deleting user: $e');
    }
  }

  void logout() {
    state = null;
  }
}

final userProvider = StateNotifierProvider<UserNotifier, User?>((ref) {
  final apiService = ref.watch(apiServiceProvider);
  return UserNotifier(apiService);
});
